	<footer id="footer">
		<div class="copyright">
			<div class="container">
				<p>&copy; Copyright <?php echo date('Y');?> | All Rights Reserved | Powered by <a href="http://covenantuniversity.edu.ng/About-Us/Centre-for-Systems-and-Information-Services-CSIS">CSIS, Covenant University</a></p>
			</div>
		</div>
	</footer> <!-- end #footer -->

</div> <!-- end #main-wrapper -->

<!-- Scripts -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="assets/js/jquery-1.11.0.min.js"><\/script>')</script>
<script src="http://maps.google.com/maps/api/js?sensor=false&libraries=geometry&v=3.7"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/maplace.min.js"></script>
<script src="assets/js/jquery.ba-outside-events.min.js"></script>
<script src="assets/js/jquery.responsive-tabs.js"></script>
<script src="assets/js/jquery.flexslider-min.js"></script>
<script src="assets/js/jquery.fitvids.js"></script>
<script src="assets/js/jquery-ui-1.10.4.custom.min.js"></script>
<script src="assets/js/jquery.inview.min.js"></script>
<script src="assets/js/script.js"></script>

</body>
</html>